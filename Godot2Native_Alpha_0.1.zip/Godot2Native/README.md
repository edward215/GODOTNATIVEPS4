# Godot2Native — Alpha 0.1

Analizador local de proyectos Godot 4.x para preparar futuras conversiones a plataformas nativas.
Esta primera versión **no compila ni convierte juegos para PS4**: inventaría el proyecto, analiza escenas/scripts,
detecta señales de compatibilidad y genera un informe JSON/Markdown.

## Requisitos
- Windows 10/11
- Python 3.10 o posterior
- No requiere paquetes externos (la interfaz usa Tkinter).

## Ejecutar
Desde PowerShell:

```powershell
cd Godot2Native
py -m godot2native
```

O analizar desde consola:

```powershell
py -m godot2native.cli "C:\ruta\al\proyecto"
py -m godot2native.cli "C:\ruta\al\proyecto" --json report.json --markdown report.md
```

## Funciones Alpha 0.1
- Localiza y valida `project.godot`.
- Lee escenas `.tscn` y extrae nodos, tipos, recursos externos e instancias.
- Analiza scripts `.gd` con patrones conservadores.
- Inventaría recursos comunes.
- Genera compatibilidad preliminar con categorías `supported`, `review` y `unsupported`.
- Exporta informes JSON y Markdown.

## Limitaciones conocidas
- El análisis GDScript es estático y basado en patrones; no ejecuta código.
- No resuelve todas las clases heredadas ni las dependencias dinámicas.
- No certifica compatibilidad con PS4 ni reemplaza pruebas en hardware.
- No modifica el proyecto original.
- GDExtension, plugins, shaders personalizados y llamadas nativas se marcan para revisión.

## Estructura
```text
godot2native/
  analyzer/       análisis del proyecto, escenas y scripts
  compatibility/  reglas iniciales de compatibilidad
  models.py       modelos de datos
  reporting.py    exportación JSON/Markdown
  ui.py           interfaz Tkinter
  cli.py          interfaz de consola
tests/            pruebas automatizadas
examples/         proyecto Godot 2D de prueba mínimo
```

## Ejecutar pruebas
```powershell
py -m unittest discover -s tests -v
```

## Próximos hitos
1. Mejorar el parser de TSCN y el análisis de dependencias.
2. Añadir reglas versionadas por versión exacta de Godot.
3. Crear pruebas de conformidad con proyectos reales.
4. Empezar el port de Godot como plataforma separada, cuando exista acceso autorizado al SDK y documentación de plataforma.
