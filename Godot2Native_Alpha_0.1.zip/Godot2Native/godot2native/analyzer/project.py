from __future__ import annotations
import configparser
import re
from pathlib import Path
from collections import Counter
from godot2native.models import ProjectReport, SceneInfo, ScriptInfo, Finding
from godot2native.compatibility.rules import analyze_text, classify_node

ANALYZER_VERSION = "0.1.0"
IGNORED_DIRS = {".git", ".godot", ".import", ".vscode", ".idea", "__pycache__"}
RESOURCE_EXTENSIONS = {
    ".png": "images", ".jpg": "images", ".jpeg": "images", ".webp": "images",
    ".svg": "images", ".wav": "audio", ".ogg": "audio", ".mp3": "audio",
    ".ttf": "fonts", ".otf": "fonts", ".glb": "3d_models", ".gltf": "3d_models",
    ".obj": "3d_models", ".tscn": "scenes", ".tres": "resources",
    ".gd": "scripts", ".cs": "csharp_scripts", ".gdshader": "shaders",
    ".godot": "config"
}

def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig", errors="replace")

def _parse_engine_version(config_text: str) -> str | None:
    match = re.search(r'(?m)^config/features\s*=\s*\[(.*?)\]', config_text, re.S)
    if match:
        version = re.search(r'"(\d+\.\d+)"', match.group(1))
        if version:
            return version.group(1)
    return None

def _parse_project_name(config_text: str, fallback: str) -> str:
    match = re.search(r'(?m)^config/name\s*=\s*"((?:\\.|[^"])*)"', config_text)
    return match.group(1).replace(r'\"', '"') if match else fallback

def _safe_relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()

def _scan_scene(path: Path, root: Path) -> SceneInfo:
    text = _read_text(path)
    node_types = re.findall(r'(?m)^\[node\b[^\]]*?\btype="([^"]+)"', text)
    ext = re.findall(r'(?m)^\[ext_resource\b[^\]]*?\bpath="([^"]+)"', text)
    instances = re.findall(r'(?m)^\[node\b[^\]]*?\binstance=ExtResource\("([^"]+)"\)', text)
    # Preserve unique values while retaining file order.
    return SceneInfo(
        path=_safe_relative(path, root),
        node_count=len(node_types),
        node_types=list(dict.fromkeys(node_types)),
        external_resources=list(dict.fromkeys(ext)),
        instanced_scenes=list(dict.fromkeys(instances)),
    )

def _scan_script(path: Path, root: Path) -> tuple[ScriptInfo, list[Finding]]:
    text = _read_text(path)
    extends_match = re.search(r'(?m)^\s*extends\s+([A-Za-z_][A-Za-z0-9_.]*)', text)
    functions = re.findall(r'(?m)^\s*(?:static\s+)?func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(', text)
    features, findings = analyze_text(text, _safe_relative(path, root))
    return ScriptInfo(
        path=_safe_relative(path, root),
        extends=extends_match.group(1) if extends_match else None,
        functions=list(dict.fromkeys(functions)),
        detected_features=features,
        line_count=len(text.splitlines()),
    ), findings

def analyze_project(project_dir: str | Path) -> ProjectReport:
    root = Path(project_dir).expanduser().resolve()
    config_path = root / "project.godot"
    if not root.is_dir():
        raise FileNotFoundError(f"No existe la carpeta: {root}")
    if not config_path.is_file():
        raise FileNotFoundError(f"No se encontró project.godot en: {root}")

    config_text = _read_text(config_path)
    report = ProjectReport(
        project_path=str(root),
        project_name=_parse_project_name(config_text, root.name),
        engine_config_version=_parse_engine_version(config_text),
        analyzer_version=ANALYZER_VERSION,
    )

    counts: Counter[str] = Counter()
    node_counts: Counter[str] = Counter()
    for current, dirs, filenames in __import__("os").walk(root):
        dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS)
        base = Path(current)
        for filename in sorted(filenames):
            path = base / filename
            ext = path.suffix.lower()
            if ext in RESOURCE_EXTENSIONS:
                counts[RESOURCE_EXTENSIONS[ext]] += 1
            if ext == ".tscn":
                scene = _scan_scene(path, root)
                report.scenes.append(scene)
                for node_type in scene.node_types:
                    node_counts[node_type] += 1
                    status, message = classify_node(node_type)
                    if status != "supported":
                        report.findings.append(Finding(
                            code=f"NODE_{status.upper()}",
                            severity="warning" if status == "review" else "error",
                            category="scene_node",
                            message=f"{node_type}: {message}",
                            file=scene.path,
                            recommendation="Revisar el nodo y validar su implementación en el backend objetivo."
                        ))
            elif ext == ".gd":
                script, findings = _scan_script(path, root)
                report.scripts.append(script)
                report.findings.extend(findings)

    if report.engine_config_version is None:
        report.findings.append(Finding(
            code="ENGINE_VERSION_UNKNOWN", severity="warning", category="project",
            message="No se pudo determinar la versión de Godot desde config/features.",
            file="project.godot",
            recommendation="Abrir el proyecto con la versión de Godot prevista y revisar project.godot."
        ))

    if counts.get("csharp_scripts", 0):
        report.findings.append(Finding(
            code="CSHARP_REVIEW", severity="warning", category="language",
            message="Se detectaron scripts C#. La compatibilidad de .NET requiere una estrategia específica.",
            recommendation="No asumir que el runtime .NET de escritorio está disponible en la plataforma objetivo."
        ))
    if counts.get("shaders", 0):
        report.findings.append(Finding(
            code="CUSTOM_SHADERS_REVIEW", severity="warning", category="rendering",
            message="Se detectaron shaders personalizados; deben validarse y posiblemente adaptarse.",
            recommendation="Crear pruebas de compilación y renderizado para cada shader."
        ))

    report.resources = dict(sorted(counts.items()))
    report.node_type_counts = dict(sorted(node_counts.items()))
    report.summary = {
        "scene_count": len(report.scenes),
        "script_count": len(report.scripts),
        "resource_file_count": sum(counts.values()),
        "finding_count": len(report.findings),
        "error_count": sum(1 for f in report.findings if f.severity == "error"),
        "warning_count": sum(1 for f in report.findings if f.severity == "warning"),
    }
    return report
