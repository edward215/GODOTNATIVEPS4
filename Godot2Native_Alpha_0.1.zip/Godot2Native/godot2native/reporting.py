from __future__ import annotations
import json
from pathlib import Path
from godot2native.models import ProjectReport

def write_json(report: ProjectReport, destination: str | Path) -> Path:
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return path

def to_markdown(report: ProjectReport) -> str:
    lines = [
        f"# Informe Godot2Native: {report.project_name}", "",
        f"- **Ruta:** `{report.project_path}`",
        f"- **Versión detectada:** {report.engine_config_version or 'Desconocida'}",
        f"- **Analizador:** {report.analyzer_version}", "",
        "## Resumen", "",
        "| Métrica | Cantidad |", "|---|---:|",
    ]
    for key, value in report.summary.items():
        lines.append(f"| {key.replace('_', ' ').title()} | {value} |")
    lines += ["", "## Tipos de nodos", "", "| Tipo | Cantidad |", "|---|---:|"]
    for name, count in report.node_type_counts.items():
        lines.append(f"| `{name}` | {count} |")
    lines += ["", "## Recursos", "", "| Categoría | Archivos |", "|---|---:|"]
    for name, count in report.resources.items():
        lines.append(f"| {name} | {count} |")
    lines += ["", "## Hallazgos", ""]
    if not report.findings:
        lines.append("No se detectaron hallazgos con las reglas actuales.")
    else:
        for finding in report.findings:
            location = f" — `{finding.file}`" if finding.file else ""
            if finding.line:
                location += f":{finding.line}"
            lines.append(f"- **{finding.severity.upper()} · {finding.code}**{location}: {finding.message}")
            if finding.recommendation:
                lines.append(f"  - Recomendación: {finding.recommendation}")
    lines += ["", "> Este informe es un análisis estático preliminar. No garantiza compatibilidad ni sustituye pruebas en hardware.", ""]
    return "\n".join(lines)

def write_markdown(report: ProjectReport, destination: str | Path) -> Path:
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(to_markdown(report), encoding="utf-8")
    return path
