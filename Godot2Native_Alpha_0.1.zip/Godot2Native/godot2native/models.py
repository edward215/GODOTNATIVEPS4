from __future__ import annotations
from dataclasses import asdict, dataclass, field
from typing import Any

@dataclass
class Finding:
    code: str
    severity: str
    category: str
    message: str
    file: str | None = None
    line: int | None = None
    recommendation: str | None = None

@dataclass
class SceneInfo:
    path: str
    node_count: int = 0
    node_types: list[str] = field(default_factory=list)
    external_resources: list[str] = field(default_factory=list)
    instanced_scenes: list[str] = field(default_factory=list)

@dataclass
class ScriptInfo:
    path: str
    extends: str | None = None
    functions: list[str] = field(default_factory=list)
    detected_features: list[str] = field(default_factory=list)
    line_count: int = 0

@dataclass
class ProjectReport:
    project_path: str
    project_name: str
    engine_config_version: str | None
    analyzer_version: str
    scenes: list[SceneInfo] = field(default_factory=list)
    scripts: list[ScriptInfo] = field(default_factory=list)
    resources: dict[str, int] = field(default_factory=dict)
    node_type_counts: dict[str, int] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    summary: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
