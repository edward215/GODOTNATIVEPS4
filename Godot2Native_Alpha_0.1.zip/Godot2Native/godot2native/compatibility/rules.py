from __future__ import annotations
import re
from godot2native.models import Finding

# Estado preliminar del analizador, no certificación oficial de compatibilidad.
NODE_RULES = {
    "Node2D": ("supported", "Nodo 2D base previsto para el primer alcance."),
    "Sprite2D": ("supported", "Sprite 2D previsto para el primer alcance."),
    "AnimatedSprite2D": ("supported", "Animación por frames prevista para el primer alcance."),
    "CharacterBody2D": ("supported", "Cuerpo cinemático 2D previsto para el primer alcance."),
    "StaticBody2D": ("supported", "Cuerpo estático 2D previsto para el primer alcance."),
    "RigidBody2D": ("supported", "Cuerpo rígido 2D previsto para el primer alcance."),
    "CollisionShape2D": ("supported", "Forma de colisión 2D prevista para el primer alcance."),
    "Area2D": ("supported", "Área 2D prevista para el primer alcance."),
    "TileMapLayer": ("review", "Requiere validación de TileMapLayer y sus datos de tiles."),
    "AnimationPlayer": ("review", "Requiere validar pistas, métodos y recursos de animación."),
    "Camera2D": ("review", "Requiere validar límites, smoothing y comportamiento de cámara."),
    "CanvasItem": ("review", "Requiere validar el pipeline CanvasItem."),
    "Control": ("review", "La interfaz de usuario queda fuera del primer conjunto de pruebas."),
    "Node3D": ("unsupported", "Los nodos 3D quedan fuera del alcance Alpha 0.1."),
    "CharacterBody3D": ("unsupported", "Los nodos 3D quedan fuera del alcance Alpha 0.1."),
}

SCRIPT_PATTERNS = [
    ("GDExtension", r"\bGDExtension\b|class_name\s+\w+"),
    ("Threading", r"\bThread\b|WorkerThreadPool"),
    ("Networking", r"\bENetMultiplayerPeer\b|\bWebSocketPeer\b|\bHTTPClient\b"),
    ("FileAccess", r"\bFileAccess\b|\bDirAccess\b"),
    ("Subprocess", r"\bOS\.execute\b|\bOS\.create_process\b"),
    ("RenderingServer", r"\bRenderingServer\b|\bRenderingDevice\b"),
    ("CSharpInterop", r"\bCSharpScript\b"),
]

def classify_node(node_type: str) -> tuple[str, str]:
    if node_type in NODE_RULES:
        return NODE_RULES[node_type]
    if node_type.endswith("3D"):
        return "unsupported", "Los nodos 3D no forman parte del alcance inicial 2D."
    return "review", "Tipo de nodo no incluido en la matriz inicial; requiere validación."

def analyze_text(text: str, file_path: str) -> tuple[list[str], list[Finding]]:
    features: list[str] = []
    findings: list[Finding] = []
    for name, pattern in SCRIPT_PATTERNS:
        match = re.search(pattern, text)
        if match:
            features.append(name)
            severity = "error" if name == "GDExtension" else "warning"
            findings.append(Finding(
                code=f"SCRIPT_FEATURE_{name.upper()}",
                severity=severity,
                category="script",
                message=f"Se detectó uso potencial de {name} en el script.",
                file=file_path,
                line=text[:match.start()].count("\n") + 1,
                recommendation="Revisar dependencias y disponibilidad de esta API en el port de plataforma."
            ))
    return features, findings
