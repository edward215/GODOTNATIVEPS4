from __future__ import annotations
import argparse
from pathlib import Path
from godot2native.analyzer.project import analyze_project
from godot2native.reporting import write_json, write_markdown

def main() -> int:
    parser = argparse.ArgumentParser(description="Analiza un proyecto Godot para Godot2Native.")
    parser.add_argument("project", help="Carpeta que contiene project.godot")
    parser.add_argument("--json", dest="json_path", help="Ruta de salida del informe JSON")
    parser.add_argument("--markdown", dest="markdown_path", help="Ruta de salida del informe Markdown")
    args = parser.parse_args()
    try:
        report = analyze_project(args.project)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    print(f"Proyecto: {report.project_name}")
    print(f"Escenas: {report.summary['scene_count']} | Scripts: {report.summary['script_count']}")
    print(f"Hallazgos: {report.summary['finding_count']} "
          f"(errores: {report.summary['error_count']}, avisos: {report.summary['warning_count']})")
    if args.json_path:
        print(f"JSON: {write_json(report, args.json_path)}")
    if args.markdown_path:
        print(f"Markdown: {write_markdown(report, args.markdown_path)}")
    if not args.json_path and not args.markdown_path:
        default = Path(args.project) / "godot2native-report.json"
        write_json(report, default)
        print(f"Informe guardado: {default}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
