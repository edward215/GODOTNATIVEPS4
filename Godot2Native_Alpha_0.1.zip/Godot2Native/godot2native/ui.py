from __future__ import annotations
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from godot2native.analyzer.project import analyze_project
from godot2native.reporting import write_json, write_markdown

class AnalyzerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Godot2Native — Project Analyzer Alpha 0.1")
        self.root.geometry("900x650")
        self.root.minsize(720, 500)
        self.project_path: Path | None = None
        self.report = None
        self._build()

    def _build(self):
        outer = ttk.Frame(self.root, padding=16)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Godot2Native", font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Project Analyzer · Alpha 0.1", foreground="#666").pack(anchor="w", pady=(0, 14))

        row = ttk.Frame(outer)
        row.pack(fill="x")
        self.path_var = tk.StringVar(value="Selecciona una carpeta de proyecto Godot…")
        ttk.Entry(row, textvariable=self.path_var, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Examinar…", command=self.choose_project).pack(side="left", padx=(8, 0))
        ttk.Button(row, text="Analizar proyecto", command=self.run_analysis).pack(side="left", padx=(8, 0))

        self.status = tk.StringVar(value="Listo. El análisis es estático y no modifica el proyecto.")
        ttk.Label(outer, textvariable=self.status).pack(anchor="w", pady=10)

        self.summary = ttk.LabelFrame(outer, text="Resumen", padding=10)
        self.summary.pack(fill="x", pady=(0, 10))
        self.summary_text = tk.StringVar(value="Todavía no hay ningún análisis.")
        ttk.Label(self.summary, textvariable=self.summary_text, justify="left").pack(anchor="w")

        findings_frame = ttk.LabelFrame(outer, text="Hallazgos de compatibilidad", padding=8)
        findings_frame.pack(fill="both", expand=True)
        columns = ("severity", "code", "file", "message")
        self.tree = ttk.Treeview(findings_frame, columns=columns, show="headings")
        for col, title, width in [
            ("severity", "Nivel", 85), ("code", "Código", 190),
            ("file", "Archivo", 180), ("message", "Descripción", 390)
        ]:
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w")
        scrollbar = ttk.Scrollbar(findings_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="Exportar JSON…", command=self.export_json).pack(side="left")
        ttk.Button(buttons, text="Exportar Markdown…", command=self.export_markdown).pack(side="left", padx=8)
        ttk.Label(buttons, text="No genera paquetes PS4.", foreground="#8a4b08").pack(side="right")

    def choose_project(self):
        selected = filedialog.askdirectory(title="Selecciona la carpeta que contiene project.godot")
        if selected:
            self.project_path = Path(selected)
            self.path_var.set(str(self.project_path))
            self.status.set("Proyecto seleccionado. Pulsa «Analizar proyecto».")

    def run_analysis(self):
        if not self.project_path:
            messagebox.showinfo("Selecciona un proyecto", "Primero selecciona una carpeta Godot.")
            return
        try:
            self.status.set("Analizando…")
            self.root.update_idletasks()
            self.report = analyze_project(self.project_path)
            for item in self.tree.get_children():
                self.tree.delete(item)
            for finding in self.report.findings:
                self.tree.insert("", "end", values=(
                    finding.severity.upper(), finding.code, finding.file or "", finding.message
                ))
            s = self.report.summary
            self.summary_text.set(
                f"Proyecto: {self.report.project_name}\n"
                f"Godot detectado: {self.report.engine_config_version or 'desconocido'}\n"
                f"Escenas: {s['scene_count']}  |  Scripts: {s['script_count']}  |  Recursos: {s['resource_file_count']}\n"
                f"Hallazgos: {s['finding_count']}  |  Errores: {s['error_count']}  |  Avisos: {s['warning_count']}"
            )
            self.status.set("Análisis terminado. El proyecto original no se ha modificado.")
        except Exception as exc:
            self.status.set("Error durante el análisis.")
            messagebox.showerror("Error de análisis", str(exc))

    def export_json(self):
        if not self.report:
            messagebox.showinfo("Sin informe", "Primero analiza un proyecto.")
            return
        target = filedialog.asksaveasfilename(
            title="Guardar informe JSON", defaultextension=".json",
            filetypes=[("JSON", "*.json")], initialfile="godot2native-report.json"
        )
        if target:
            write_json(self.report, target)
            self.status.set(f"Informe JSON guardado: {target}")

    def export_markdown(self):
        if not self.report:
            messagebox.showinfo("Sin informe", "Primero analiza un proyecto.")
            return
        target = filedialog.asksaveasfilename(
            title="Guardar informe Markdown", defaultextension=".md",
            filetypes=[("Markdown", "*.md")], initialfile="godot2native-report.md"
        )
        if target:
            write_markdown(self.report, target)
            self.status.set(f"Informe Markdown guardado: {target}")

def launch():
    root = tk.Tk()
    AnalyzerApp(root)
    root.mainloop()
