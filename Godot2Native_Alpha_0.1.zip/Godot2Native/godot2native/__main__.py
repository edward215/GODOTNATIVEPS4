from godot2native.ui import launch

if __name__ == "__main__":
    launch()
