import tempfile
import unittest
from pathlib import Path
from godot2native.analyzer.project import analyze_project

class AnalyzerTests(unittest.TestCase):
    def test_scans_minimal_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "project.godot").write_text(
                '[application]\nconfig/name="TestGame"\nconfig/features=["4.3", "GL Compatibility"]\n',
                encoding="utf-8"
            )
            (root / "main.tscn").write_text(
                '[gd_scene load_steps=2 format=3]\n'
                '[ext_resource type="Script" path="res://player.gd" id="1"]\n'
                '[node name="Root" type="Node2D"]\n'
                '[node name="Player" type="CharacterBody2D" parent="."]\n',
                encoding="utf-8"
            )
            (root / "player.gd").write_text(
                'extends CharacterBody2D\nfunc _physics_process(delta):\n    pass\n',
                encoding="utf-8"
            )
            report = analyze_project(root)
            self.assertEqual(report.project_name, "TestGame")
            self.assertEqual(report.engine_config_version, "4.3")
            self.assertEqual(report.summary["scene_count"], 1)
            self.assertEqual(report.summary["script_count"], 1)
            self.assertEqual(report.scenes[0].node_count, 2)

    def test_requires_project_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundError):
                analyze_project(tmp)

if __name__ == "__main__":
    unittest.main()
